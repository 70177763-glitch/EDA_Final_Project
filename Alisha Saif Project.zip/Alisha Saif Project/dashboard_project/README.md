# 🔴 HIV/AIDS Global Analytics Dashboard

**Course:** Exploratory Data Analysis  
**Instructor:** Ali Hassan Sherazi  
**Submission Date:** 05-June-2026  
**Dataset:** `aidsinfo.unaids.org.csv` (2,509,456 records · 14 columns · 1990–2024)

---

## Dataset Description

The dataset is sourced from **UNAIDS** (aidsinfo.unaids.org) and contains global HIV/AIDS epidemiological estimates published in 2025. It covers:

- **50 HIV/AIDS indicators** (mortality rates, prevalence, ART coverage, orphan counts, etc.)
- **228 geographic areas** (countries, regions, global aggregates)
- **35 years** of data (1990–2024)
- **8 data sources** (UNAIDS Estimates, Global AIDS Monitoring, Spectrum, etc.)
- **3 unit types** — Rate, Number, Percent
- **96 subgroups** — breakdowns by sex (male/female), age group, and estimate type

---

## Setup & Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the dashboard
streamlit run app.py
```

The dashboard opens at `http://localhost:8501`

---

## Project Structure

```
dashboard_project/
├── data/
│   └── aidsinfo.unaids.org.csv     ← exact filename, do NOT rename
├── app.py                           ← main Streamlit application
├── charts.py                        ← all 10 chart functions + bonus
├── filters.py                       ← data loading, cleaning, filtering
├── requirements.txt
├── README.md
├── EXPLANATION.txt
└── notebooks/
    └── analysis.ipynb               ← complete EDA notebook
```

---

## Dashboard Features

| Feature | Details |
|---|---|
| KPI Cards | Total Records · Total Areas · Total Indicators · Avg/Max/Min Data Value · Total Sources |
| Charts | 10 required chart types + 1 bonus pair plot |
| Filters | 8 interactive filters all linked to every chart |
| Sidebar | Collapsible, styled, reset button |
| Responsiveness | Wide layout, 2-column chart grid |
| Performance | `@st.cache_data` caches 2.5M-row CSV load · random sampling for heavy charts |

### Interactive Filters

1. **Time Period Range** — slider from 1990 to 2024
2. **Area** — multi-select country/region
3. **Indicator** — multi-select HIV/AIDS indicator
4. **Unit Type** — Rate / Number / Percent
5. **Data Source** — multi-select by organisation
6. **Area Level** — Global / Regional / National
7. **Subgroup** — sex/age/estimate-type breakdown
8. **Data Value Range** — numerical range slider

---

## Charts Included

| # | Chart Type | Variable(s) | Insight |
|---|---|---|---|
| 1 | Pie Chart | Unit | Proportional split of measurement unit types |
| 2 | Histogram | Data_Value | Distribution shape of all HIV/AIDS measurements |
| 3 | Line Chart | Time_Period → Data_Value | Global indicator trend 1990–2024 |
| 4 | Bar Chart | Area → Data_Value | Top 10 areas by average data value |
| 5 | Scatter Plot | Time_Period vs Data_Value (by Unit) | Value evolution over time |
| 6 | Box Plot | Unit → Data_Value | Spread and outliers per unit type |
| 7 | Heatmap | Indicator × Indicator | Correlation between indicators over time |
| 8 | Area Chart | Time_Period → Cumulative Count | Growth of reporting records over decades |
| 9 | Count Plot | Source | Data source contribution frequency |
| 10 | Violin Plot | Area_Level → Data_Value | Distribution shape by geographic level |
| ✨ | Pair Plot | Time_Period, Data_Value, Area_Level (by Unit) | Multi-dimensional pairwise overview |

---

## Key Insights

1. **Data Growth** — Reporting records have grown dramatically from 1990 onward, reflecting expanded global surveillance infrastructure.
2. **Dominant Source** — UNAIDS Estimates accounts for the majority of records, indicating centralised modelling underpins global HIV statistics.
3. **Value Distribution** — Data values are heavily right-skewed: most indicators are small rates or percentages, while absolute numbers (e.g. total PLHIV) are orders of magnitude larger.
4. **Regional Disparity** — Sub-Saharan African countries consistently show the highest absolute counts for AIDS-related deaths and people living with HIV.
5. **ART Coverage Trend** — Coverage of people living with HIV receiving ART has risen sharply post-2010, correlating with declining AIDS-related mortality rates.
6. **Indicator Correlation** — AIDS-related deaths and new HIV infections are strongly positively correlated, confirming that untreated infection drives mortality.
7. **Area Level Spread** — National-level data shows the widest variance, expected because individual country burdens differ vastly; global aggregates are narrow.

---

## Technologies Used

| Library | Version | Purpose |
|---|---|---|
| Streamlit | ≥ 1.32 | Web dashboard framework |
| Pandas | ≥ 2.0 | Data loading, cleaning, filtering |
| NumPy | ≥ 1.26 | Numerical operations |
| Matplotlib | ≥ 3.8 | Base chart rendering |
| Seaborn | ≥ 0.13 | Statistical visualisations |
